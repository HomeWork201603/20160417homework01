//匿名函数方式
oTab =document.getElementById('outer');
oLi = oTab.getElementsByTagName('li');
oDiv =oTab.getElementsByTagName('div');

// for (var i = 0; i < oLi.length; i++) {
// 	!function(i){
// 		//console.log(i);
// 		oLi[i].onmouseover =function(){
// 			for (var j = 0; j < oLi.length; j++) {
// 			oLi[j].className = '';
// 			oDiv[j].className = '';
// 			}

// 			this.className = 'selected';
// 			oDiv[i].className ='selected';
// 		};
// 	}(i);
// }

//另一种方法，
function tabChange(i){
	oLi[i].onmouseover =function(){
		for (var j = 0; j < oLi.length; j++) {
			oLi[j].className ='';
			oDiv[j].className ='';
		}
		this.className ='selected';
		oDiv[i].className ='selected';
	};
}

for (var i = 0; i < oLi.length; i++) {
	tabChange(i);
}